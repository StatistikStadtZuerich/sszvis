# Line Chart

## Simple Line Chart

Ein Liniendiagramm eignet sich, um die – meistens zeitliche – Veränderung eines Wertes darzustellen.

```specimen-project
{
    "index": "docs/simple-line-chart/index.html",
    "readme": "docs/simple-line-chart/README.md",
    "files": [
        "docs/simple-line-chart/data.csv"
    ],
    "size": {
        "height": 400,
        "width": "100%"
    }
}
```

[Projekt herunterladen](docs/downloads/line-chart.zip) (ZIP)

### Datenformat

Dieses Chart benötigt zwei Datenreihen:

* x-Achse
* y-Achse

### Konfiguration

Es stehen folgende Konfigurationsmöglichkeiten zur Verfügung:

* `xAxis` – eine `d3`-Achsenfunktion
* `yAxis` – eine `d3`-Achsenfunktion

